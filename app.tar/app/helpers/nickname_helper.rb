module NicknameHelper
end
