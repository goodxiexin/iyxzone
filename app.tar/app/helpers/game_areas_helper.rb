module GameAreasHelper
end
