module Admin::HotWordsHelper
end
