module Admin::AlbumsHelper
end
