module Admin::SignupInvitationsHelper
end
