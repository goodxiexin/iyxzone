module Admin::NewsPicturesHelper
end
