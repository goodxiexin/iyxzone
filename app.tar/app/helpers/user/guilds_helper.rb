module User::GuildsHelper

end
