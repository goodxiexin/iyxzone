module User::PhotoTagsHelper


end
