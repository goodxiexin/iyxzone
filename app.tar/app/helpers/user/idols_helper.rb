module User::IdolsHelper
end
