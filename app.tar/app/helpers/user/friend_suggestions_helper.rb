module User::FriendSuggestionsHelper
end
