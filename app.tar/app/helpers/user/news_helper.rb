module User::NewsHelper
end
