module User::TempSignupInvitationsHelper
end
