module User::MiniLinksHelper
end
