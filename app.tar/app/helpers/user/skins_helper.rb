module User::SkinsHelper
end
