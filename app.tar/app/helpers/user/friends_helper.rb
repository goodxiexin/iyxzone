module User::FriendsHelper
end
