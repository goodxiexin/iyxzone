module User::LinksHelper
end
