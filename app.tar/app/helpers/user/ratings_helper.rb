module User::RatingsHelper
end
