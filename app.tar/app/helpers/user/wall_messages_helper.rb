module User::WallMessagesHelper
end
