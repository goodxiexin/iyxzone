module User::SearchHelper
end
