module User::GuildRulesHelper
end
