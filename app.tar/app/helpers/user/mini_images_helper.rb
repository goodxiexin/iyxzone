module User::MiniImagesHelper
end
