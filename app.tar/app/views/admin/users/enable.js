page << "$('user_#{@user.id}').childElements()[3].innerHTML = 
