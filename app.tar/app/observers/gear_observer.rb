class GearObserver < ActiveRecord::Observer


end
