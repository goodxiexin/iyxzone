class TagObserver < ActiveRecord::Observer

end
