class GuildRuleObserver < ActiveRecord::Observer

end
