class MiniTopicFreqNode < ActiveRecord::Base
end
