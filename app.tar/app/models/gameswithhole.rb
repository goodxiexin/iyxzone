class Gameswithhole < ActiveRecord::Base
end
