class LoginChangeCode < ActiveRecord::Base
end
