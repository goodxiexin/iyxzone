class DeletedIndex < ActiveRecord::Base
end
