class MiniTopicNode < ActiveRecord::Base

  belongs_to :mini_topic

end
