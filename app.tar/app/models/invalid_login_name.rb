class InvalidLoginName < ActiveRecord::Base
  
  belongs_to :user

end
