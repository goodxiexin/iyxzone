class ChineseCharacter < ActiveRecord::Base
end
