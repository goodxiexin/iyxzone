class MiniBlogMetaData < ActiveRecord::Base

  serialize :random_ids, Array

end
