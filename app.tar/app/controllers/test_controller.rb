class TestController < ApplicationController

  def show
  end

end
