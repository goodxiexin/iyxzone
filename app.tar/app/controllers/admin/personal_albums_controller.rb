class Admin::PersonalAlbumsController < ApplicationController
end
