class User::AccountSettingController < UserBaseController
end
