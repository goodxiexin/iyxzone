class User::TempSignupInvitationsController < ApplicationController

  def index
  end

end
