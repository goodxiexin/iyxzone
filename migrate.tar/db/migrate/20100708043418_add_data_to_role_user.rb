class AddDataToRoleUser < ActiveRecord::Migration
  def self.up
    add_column :role_users, :data, :integer
  end

  def self.down
    remove_column :role_users, :data, :integer
  end
end
