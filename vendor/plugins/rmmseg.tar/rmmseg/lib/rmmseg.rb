require File.join(File.dirname(__FILE__), 'rmmseg', 'dictionary')
require File.join(File.dirname(__FILE__), 'rmmseg', 'ferret')
require File.join(File.dirname(__FILE__), '..', 'ext', 'rmmseg', 'rmmseg')
