# $Id$

require File.join(File.dirname(__FILE__), %w[spec_helper])

describe RMMSeg do
end

# EOF
